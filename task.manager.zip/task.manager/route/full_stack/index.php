<?php
include($_SERVER["DOCUMENT_ROOT"] . "/template/header.php");
include($_SERVER["DOCUMENT_ROOT"] . "/template/form.php");
include($_SERVER["DOCUMENT_ROOT"] . "/template/footer.php");