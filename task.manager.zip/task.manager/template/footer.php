<div class="footer-menu clearfix">

    <?php
        renderMenu($mainMenu, 'desc', "main-menu bottom", "active");
    ?>

</div>

<div class="footer">&copy;&nbsp;<nobr>2020</nobr>
    Project.
</div>


</body>
</html>
