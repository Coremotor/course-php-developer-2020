<div class="footer-menu clearfix">
    <ul class="main-menu bottom">

        <?php

            renderMenu($mainMenu, 'fz12', 'desc', "main-menu bottom");
        ?>

    </ul>
</div>

<div class="footer">&copy;&nbsp;<nobr>2020</nobr>
    Project.
</div>

