<?php
$passwords = ['a', 'u'];