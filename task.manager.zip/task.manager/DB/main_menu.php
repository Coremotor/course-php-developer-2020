<?php

$mainMenu = [
    [
        "title" => "HTML5",
        "path" => "/route/html/",
        "sort" => 3
    ],
    [
        "title" => "CSS3",
        "path" => "/route/css/",
        "sort" => 2
    ],
    [
        "title" => "JavaScript",
        "path" => "/route/js/",
        "sort" => 4
    ],
    [
        "title" => "PHP",
        "path" => "/route/php/",
        "sort" => 1
    ],
    [
        "title" => "Full Stack Web Developer",
        "path" => "/route/full_stack/",
        "sort" => 5
    ],
];

