<?php
$logins = ['admin', 'user'];