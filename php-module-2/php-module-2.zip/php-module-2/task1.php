<pre>

<?php

$result1 = [
    "author" => [
        "authorName" => "Oleg Divov",
        "authorEmail" => "divov@pochta.ru",
    ],

    "book" => [
        "bookName" => "Vibrakovka",
        "bookAuthorEmail" => "divov@pochta.ru",
    ]
];

var_dump($result1);

?>

</pre>

