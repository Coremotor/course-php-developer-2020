<pre>

<?php

$result2 = [
    "authors" => [
        [
            "authorName" => "Oleg Divov",
            "authorEmail" => "Divov@pochta.ru",
        ],
        [
            "authorName" => "Gorge Oruel",
            "authorEmail" => "Oruel@pochta.ru",
        ],
        [
            "authorName" => "Mikhail Bulgakov",
            "authorEmail" => "Bulgakov@pochta.ru",
        ],
    ],
    "books" => [
        [
            "bookName" => "Vibrakovka",
            "bookAuthorEmail" => "divov@pochta.ru",
        ],
        [
            "bookName" => "1984",
            "bookAuthorEmail" => "Oruel@pochta.ru",
        ],
        [
            "bookName" => "Master i margarita",
            "bookAuthorEmail" => "Bulgakov@pochta.ru",
        ],
    ],
];

var_dump($result2);

?>

</pre>

